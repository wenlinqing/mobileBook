const common=require('./libs/common');

var str='wlq@wlq@123';
var str=common.md5(str+'FDSW$t34tregt5tO&$(#RHuyoyiUYE*&OI$HRLuy87odlfh莎娃迪卡)');

console.log(str);
